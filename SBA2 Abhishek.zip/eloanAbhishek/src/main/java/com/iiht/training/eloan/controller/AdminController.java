package com.iiht.training.eloan.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.iiht.training.eloan.dto.UserDto;
import com.iiht.training.eloan.service.AdminService;

@RestController
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private AdminService adminService;
	
	//Tested Working
	@PostMapping("/register-clerk")
	public ResponseEntity<UserDto> registerClerk(@RequestBody UserDto userDto){
		UserDto userDtoReturn =  this.adminService.registerClerk(userDto);
		ResponseEntity<UserDto> response = new ResponseEntity<UserDto>(userDtoReturn, HttpStatus.OK);
		return response;
	}
	//Tested Working
	@PostMapping("/register-manager")
	public ResponseEntity<UserDto> registerManager(@RequestBody UserDto userDto){
		UserDto userDtoReturn =  this.adminService.registerManager(userDto);
		ResponseEntity<UserDto> response = new ResponseEntity<UserDto>(userDtoReturn, HttpStatus.OK);
		return response;
	}
	//Tested Working
	@GetMapping("/all-clerks")
	public ResponseEntity<List<UserDto>> getAllClerks(){
		List<UserDto> userList = this.adminService.getAllClerks();
		ResponseEntity<List<UserDto>> response = new ResponseEntity<List<UserDto>>(userList, HttpStatus.OK);
		return response;
	}
	//Tested Working
	@GetMapping("/all-managers")
	public ResponseEntity<List<UserDto>> getAllManagers(){
		List<UserDto> userList = this.adminService.getAllManagers();
		ResponseEntity<List<UserDto>> response = new ResponseEntity<List<UserDto>>(userList, HttpStatus.OK);
		return response;
	}
}
