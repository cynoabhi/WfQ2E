package com.iiht.training.eloan.exception;

public class ClerkNotFoundException extends RuntimeException{

	public ClerkNotFoundException(String message) {
		super(message);
	}
}
