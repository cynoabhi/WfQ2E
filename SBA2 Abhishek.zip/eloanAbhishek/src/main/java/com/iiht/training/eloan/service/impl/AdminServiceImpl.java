package com.iiht.training.eloan.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.training.eloan.dto.UserDto;
import com.iiht.training.eloan.entity.Users;
import com.iiht.training.eloan.repository.UsersRepository;
import com.iiht.training.eloan.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private UsersRepository usersRepository;
	
	//Tested working
	private UserDto convertEntityToDto(Users users) {
		UserDto userDto = new UserDto();
		userDto.setId(users.getId());
		userDto.setFirstName(users.getFirstName());
		userDto.setLastName(users.getLastName());
		userDto.setEmail(users.getEmail());
		userDto.setMobile(users.getMobile());
		return userDto;
	}
	//Tested Working
		private Users covertDtoToEntity(UserDto userDto) {
		Users users = new Users();
		users.setId(userDto.getId());
		users.setFirstName(userDto.getFirstName());
		users.setLastName(userDto.getLastName());
		users.setEmail(userDto.getEmail());
		users.setMobile(userDto.getMobile());
		
		return users;
	}
	
	//Tested working
	public UserDto registerClerk(UserDto userDto) {
		// TODO Auto-generated method stub
		//convert dto into entity
		Users users = this.covertDtoToEntity(userDto);
		users.setRole("Clerk");
		//save entity in db :returns the copy of newly added record back
		Users newuser = this.usersRepository.save(users);
		UserDto userDto1 = this.convertEntityToDto(newuser);
		return userDto1;
	}
	
	
	//Tested Working
	@Override
	public UserDto registerManager(UserDto userDto) {
	//	Users users = this.covertUserInputDtoToUserEntity(userDto, "Manager");
		Users users = this.covertDtoToEntity(userDto);
		users.setRole("Manager");
		Users newUsers = this.usersRepository.save(users);
		UserDto userDtoReturn = this.convertEntityToDto(newUsers);
		return userDtoReturn;
	}
	//Tested Working
	@Override
	public List<UserDto> getAllClerks() {
		List<Users> users = this.usersRepository.findByRole("Clerk");
		List<UserDto> usersDtos = 
				users.stream()
							 .map(this :: convertEntityToDto)
							 .collect(Collectors.toList());
		return usersDtos;
	}
	//Tested Working
	@Override
	public List<UserDto> getAllManagers() {
		List<Users> users = this.usersRepository.findByRole("Manager");
		List<UserDto> usersDtos = 
				users.stream()
							 .map(this :: convertEntityToDto)
							 .collect(Collectors.toList());
		return usersDtos;
	}
	

}
