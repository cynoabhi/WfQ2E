package com.iiht.training.eloan.service.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.training.eloan.dto.LoanDto;
import com.iiht.training.eloan.dto.LoanOutputDto;
import com.iiht.training.eloan.dto.ProcessingDto;
import com.iiht.training.eloan.dto.RejectDto;
import com.iiht.training.eloan.dto.SanctionDto;
import com.iiht.training.eloan.dto.SanctionOutputDto;
import com.iiht.training.eloan.dto.UserDto;
import com.iiht.training.eloan.entity.Loan;
import com.iiht.training.eloan.entity.ProcessingInfo;
import com.iiht.training.eloan.entity.SanctionInfo;
import com.iiht.training.eloan.entity.Users;
import com.iiht.training.eloan.exception.AlreadyFinalizedException;
import com.iiht.training.eloan.exception.LoanNotFoundException;
import com.iiht.training.eloan.exception.ManagerNotFoundException;
import com.iiht.training.eloan.repository.LoanRepository;
import com.iiht.training.eloan.repository.ProcessingInfoRepository;
import com.iiht.training.eloan.repository.SanctionInfoRepository;
import com.iiht.training.eloan.repository.UsersRepository;
import com.iiht.training.eloan.service.CustomerService;
import com.iiht.training.eloan.service.ManagerService;

@Service
public class ManagerServiceImpl implements ManagerService {

	@Autowired
	private UsersRepository usersRepository;
	
	@Autowired
	private LoanRepository loanRepository;
	
	@Autowired
	private ProcessingInfoRepository processingInfoRepository;
	
	@Autowired
	private SanctionInfoRepository sanctionInfoRepository;
	
	@Autowired
	private CustomerService customerService;


	private SanctionOutputDto convertEntityToSanctionOutputDto(SanctionInfo sanctionInfo) {
				
		SanctionOutputDto sanctionOutputDto = new SanctionOutputDto();
		sanctionOutputDto.setLoanAmountSanctioned(sanctionInfo.getLoanAmountSanctioned());
		sanctionOutputDto.setTermOfLoan(sanctionInfo.getTermOfLoan());
		sanctionOutputDto.setPaymentStartDate(sanctionInfo.getPaymentStartDate());
		sanctionOutputDto.setLoanClosureDate(sanctionInfo.getLoanClosureDate());
		sanctionOutputDto.setMonthlyPayment(sanctionInfo.getMonthlyPayment());
		
		return sanctionOutputDto;		
	}
	
	
	private ProcessingDto convertEntityToProcessingDto(ProcessingInfo processingInfo) {
		ProcessingDto processingDto = new ProcessingDto();		
		processingDto.setAcresOfLand(processingInfo.getAcresOfLand());
		processingDto.setLandValue(processingInfo.getLandValue());
		processingDto.setAppraisedBy(processingInfo.getAppraisedBy());
		processingDto.setValuationDate(processingInfo.getValuationDate());
		processingDto.setAddressOfProperty(processingInfo.getAddressOfProperty());
		processingDto.setSuggestedAmountOfLoan(processingInfo.getSuggestedAmountOfLoan());
		
		return processingDto;
			}
	
	private LoanDto convertEntityToLoanDto(Loan loan) {
		LoanDto loanDto = new LoanDto();
		loanDto.setLoanName(loan.getLoanName());
		loanDto.setLoanAmount(loan.getLoanAmount());
		loanDto.setLoanApplicationDate(loan.getLoanApplicationDate());
		loanDto.setBusinessStructure(loan.getBusinessStructure());
		loanDto.setBillingIndicator(loan.getBillingIndicator());
		loanDto.setTaxIndicator(loan.getTaxIndicator());				
		return loanDto;
	}
	
	private SanctionInfo covertSanctionDtoToSanctionInfoEntity(SanctionDto sanctionDto, Long managerId, Long loanAppId) {
		Double monthlyPaymentAmount;
		Double termPaymentAmount;
		Double interestRate=100.0;
		
		termPaymentAmount = (sanctionDto.getLoanAmountSanctioned())*(Math.pow((1+(interestRate/100)), sanctionDto.getTermOfLoan()));
		monthlyPaymentAmount=(termPaymentAmount/sanctionDto.getTermOfLoan());
		
		LocalDate paymentStartDate = LocalDate.parse(sanctionDto.getPaymentStartDate());
		LocalDate loanClosureDate = paymentStartDate.plusMonths(sanctionDto.getTermOfLoan().intValue());
		
		SanctionInfo sanctionInfo = new SanctionInfo();
		sanctionInfo.setManagerId(managerId);
		sanctionInfo.setLoanAppId(loanAppId);
		sanctionInfo.setLoanAmountSanctioned(sanctionDto.getLoanAmountSanctioned());
		sanctionInfo.setTermOfLoan(sanctionDto.getTermOfLoan());
		sanctionInfo.setPaymentStartDate(sanctionDto.getPaymentStartDate());
		sanctionInfo.setLoanClosureDate(loanClosureDate.toString());
		sanctionInfo.setMonthlyPayment(monthlyPaymentAmount);
		
	
		return sanctionInfo;
	}
		
	private LoanOutputDto covertToLoanOutputDto(LoanDto loanDto, Loan loan) {
		UserDto userDto = this.customerService.fetchSingleUser(loan.getCustomerId());
		
		LoanOutputDto loanOutputDto = new LoanOutputDto(loan.getCustomerId(), loan.getId(), 
				userDto, loanDto, loan.getRemark());
		
		if(loan.getStatus()==0) {
			loanOutputDto.setStatus("Applied");
		}
		else {
			loanOutputDto.setProcessingDto(this.fetchProcessingDTO(loan.getId()));
			if(loan.getStatus()==1) {
				loanOutputDto.setStatus("Processed");
			}
			else if(loan.getStatus()==2) {
				loanOutputDto.setStatus("Approved");
				loanOutputDto.setSanctionOutputDto(this.fetchSanctionOutputDto(loan.getId()));
			}
			else if(loan.getStatus()==-1) {
				loanOutputDto.setStatus("Rejected");
			}
		}
		return loanOutputDto;
	}
	
	private ProcessingDto fetchProcessingDTO(Long loanAppId) {
		ProcessingInfo processingInfo = this.processingInfoRepository.findByLoanAppId(loanAppId);
		ProcessingDto processingDto = this.convertEntityToProcessingDto(processingInfo);
		
		return processingDto;
	}
	
	private SanctionOutputDto fetchSanctionOutputDto(Long loanAppId) {
		SanctionInfo sanctionInfo = this.sanctionInfoRepository.findByLoanAppId(loanAppId);
		SanctionOutputDto sanctionOutputDto = this.convertEntityToSanctionOutputDto(sanctionInfo);
		return sanctionOutputDto;
	}
	
	@Override
	public List<LoanOutputDto> allProcessedLoans() {
		List<Loan> loans = this.loanRepository.findByStatus(1);//find by status
		List<LoanDto> loanDtos = 
					loans.stream()
							 .map(this :: convertEntityToLoanDto)
							 .collect(Collectors.toList());
		List<LoanOutputDto> loanOutputDtos = new ArrayList<LoanOutputDto>();
		for(int i=0;i<loanDtos.size();i++) {
			LoanOutputDto loanOutputDto = this.covertToLoanOutputDto(loanDtos.get(i), loans.get(i));
			loanOutputDtos.add(loanOutputDto);
		}
		return loanOutputDtos;
	}

	@Override
	public RejectDto rejectLoan(Long managerId, Long loanAppId, RejectDto rejectDto) {
		
		if(this.usersRepository.findByRoleId("Manager", managerId) == null)
			throw new ManagerNotFoundException("Manager not found");
		
		Loan loan = this.loanRepository.findById(loanAppId).orElse(null);
		if(loan == null)
			throw new LoanNotFoundException("Loan does not exits for this app id");
		
		if(loan.getStatus() != 1)
			throw new AlreadyFinalizedException("Loan already sanctioned or rejected or not yet processed");
		
		loan.setStatus(-1);
		loan.setRemark(rejectDto.getRemark());
		this.loanRepository.save(loan);
		return rejectDto;
	}

	@Override
	public SanctionOutputDto sanctionLoan(Long managerId, Long loanAppId, SanctionDto sanctionDto) {
		if(this.usersRepository.findByRoleId("Manager", managerId) == null)
			throw new ManagerNotFoundException("Manager not found");
		
		Loan loan = this.loanRepository.findById(loanAppId).orElse(null);
		if(loan == null)
			throw new LoanNotFoundException("Loan does not exist for this appid");
		
		if(loan.getStatus() != 1)
			throw new AlreadyFinalizedException("Loan already sanctioned or rejected or not yet processed");
		loan.setStatus(2);
		this.loanRepository.save(loan);

		SanctionInfo sanctionInfo = this.covertSanctionDtoToSanctionInfoEntity(sanctionDto, managerId, loanAppId);
		System.out.println("sanctionInfo"+sanctionInfo.getLoanAmountSanctioned()+"\n");
		SanctionInfo newSanctionInfo = this.sanctionInfoRepository.save(sanctionInfo);
		System.out.println("newSanctionInfo"+newSanctionInfo.getLoanAmountSanctioned()+"\n");
		SanctionOutputDto sanctionOutputDto = this.convertEntityToSanctionOutputDto(newSanctionInfo);
		return sanctionOutputDto;
	}

}
