package com.javatraining.sba3.PMS_SpringBootRest.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.javatraining.sba3.PMS_SpringBootRest.Entity.RecentlyViewedCompanies;


public interface RecentlyViewedCompaniesRepository extends JpaRepository<RecentlyViewedCompanies, Long>
{
    RecentlyViewedCompanies findByCompanytitle(String companytitle);
    
    @Query(value = "select  * from recently_viewed_companies order by search_date_and_time desc limit 3",nativeQuery = true)
	List<RecentlyViewedCompanies> findTopThreeRecentlyViewedCompanies();
    
}
