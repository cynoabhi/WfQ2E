package com.javatraining.sba3.PMS_SpringBootRest.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class RecentlyViewedCompanies 
{
	
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long recentlyviewedId;

	@Column(nullable = false,unique=true)
	private String companytitle;
	
	@Column(nullable = false)
	private String searchDateAndTime;
	
	@Column(nullable = false)
	private String username;
	
	public RecentlyViewedCompanies()
	{
		
	}

	public Long getRecentlyviewedId() {
		return recentlyviewedId;
	}

	public void setRecentlyviewedId(Long recentlyviewedId) {
		this.recentlyviewedId = recentlyviewedId;
	}

	public String getCompanytitle() {
		return companytitle;
	}

	public void setCompanytitle(String companytitle) {
		this.companytitle = companytitle;
	}

	public String getSearchDateAndTime() {
		return searchDateAndTime;
	}

	public void setSearchDateAndTime(String searchDateAndTime) {
		this.searchDateAndTime = searchDateAndTime;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	
	
	
	  
}
