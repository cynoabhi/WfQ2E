package com.javatraining.sba3.PMS_SpringBootRest.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.javatraining.sba3.PMS_SpringBootRest.Entity.InvestorPortfolioWallet;

public interface InvestorPortfolioWalletRepository extends JpaRepository<InvestorPortfolioWallet, Long> 
{
    //
}
