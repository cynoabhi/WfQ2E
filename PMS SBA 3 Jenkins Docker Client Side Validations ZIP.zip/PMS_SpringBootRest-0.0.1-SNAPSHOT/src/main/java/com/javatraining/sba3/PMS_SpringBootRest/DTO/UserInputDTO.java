package com.javatraining.sba3.PMS_SpringBootRest.DTO;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class UserInputDTO 
{

	@NotNull(message = "Username is mandatory")
	@NotBlank(message = "Username is mandatory")
	private String username;
	
	@NotBlank(message = "Password is mandatory")
	@NotNull(message = "Password is mandatory")
	private String password;
	
	private String usertype;
	
	@NotBlank(message = "PAN is mandatory")
	@NotNull(message = "PAN is mandatory")
	private String pan;
	
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUsertype() {
		return usertype;
	}
	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	
}
