package com.javatraining.sba3.PMS_SpringBootRest.Repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.javatraining.sba3.PMS_SpringBootRest.Entity.Stock;

@Component
public interface StockRepository extends JpaRepository<Stock, Long>
{
	List<Stock> findByCompanycode(String companycode);
	
	@Query(value = "SELECT * FROM stock WHERE stock_id IN (SELECT MAX(stock_id) FROM stock GROUP BY companytitle) order by companytitle asc",nativeQuery = true)
	List<Stock> findLatestStockRecordForEachCompany();	
	
	@Query(value = "SELECT * FROM stock where companytitle like %?1% and stock_id IN(select MAX(stock_id) from stock GROUP BY companytitle) order by companytitle asc",nativeQuery = true)
	List<Stock> findLatestStockRecordForEachCompanyTitle(String companytitle);
	
	List<Stock> findByCompanytitleOrderByStockIdDesc(String companytitle);
		
}
