package com.javatraining.sba3.PMS_SpringBootRest.Controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.javatraining.sba3.PMS_SpringBootRest.DTO.UserInputDTO;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.UserOutputDTO;
import com.javatraining.sba3.PMS_SpringBootRest.Service.UserService;


@Controller
@RequestMapping("/admin")
public class AdminController 
{

	@Autowired
	private UserService userService;
	
	@GetMapping("/") 
	public String home() 
	{ 
		String view="";
		view = "AdminHome"; 
		return view; 
	}
	
	
	@GetMapping("/add-backofficer") 
	public String addBackofficer(Model model) 
	{ 
		String view="";
		UserInputDTO userInputDTO = new UserInputDTO();
		model.addAttribute("UserInputDTO",userInputDTO);
		userInputDTO.setUsertype("backofficer");
		view = "UserRegistration"; 
		return view; 
	}
	
	@PostMapping("/save-Profile")
	public String saveProfile(@Valid @ModelAttribute("UserInputDTO") UserInputDTO userInputDTO,BindingResult result,Model model) 
	{
		String view="";
		if(result.hasErrors())
		{
			model.addAttribute("UserInputDTO", userInputDTO);
			view = "UserRegistration";
		}else
		{
			
			UserOutputDTO userName = this.userService.fetchBasedOnUserName(userInputDTO.getUsername());
			UserOutputDTO UserPan = this.userService.fetchBasedOnPAN(userInputDTO.getPan());
			if(userName==null && UserPan==null )
			{
				userInputDTO.setUsertype("backofficer");
				UserOutputDTO investorUser = this.userService.addUser(userInputDTO);
				model.addAttribute("newUserOnPMS", investorUser);
				view = "AdminHome";
			}else
			{
				model.addAttribute("UserInputDTO", userInputDTO);
				model.addAttribute("HeaderMsg","Either Username / PAN is already registered!!");
				view = "UserRegistration";
			}
		}	
		return view;
	}
}
