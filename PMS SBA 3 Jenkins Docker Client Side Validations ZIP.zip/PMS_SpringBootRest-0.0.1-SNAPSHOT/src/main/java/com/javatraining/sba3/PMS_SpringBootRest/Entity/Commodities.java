package com.javatraining.sba3.PMS_SpringBootRest.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Commodities 
{
	  @Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)  
	  private Long commodityId;
	  
	  @Column(nullable = false) 
	  private String commodityname;
	  
	  @Column(nullable = false) 
	  private double commodityprice;
	  
	  @Column(nullable = false) 
	  private String asofDateAndTime;
	  
	  public Commodities()
	  {
		  
	  }

	public Long getCommodityId() {
		return commodityId;
	}

	public void setCommodityId(Long commodityId) {
		this.commodityId = commodityId;
	}

	public String getCommodityname() {
		return commodityname;
	}

	public void setCommodityname(String commodityname) {
		this.commodityname = commodityname;
	}

	public double getCommodityprice() {
		return commodityprice;
	}

	public void setCommodityprice(double commodityprice) {
		this.commodityprice = commodityprice;
	}

	public String getAsofDateAndTime() {
		return asofDateAndTime;
	}

	public void setAsofDateAndTime(String asofDateAndTime) {
		this.asofDateAndTime = asofDateAndTime;
	}
	
}
