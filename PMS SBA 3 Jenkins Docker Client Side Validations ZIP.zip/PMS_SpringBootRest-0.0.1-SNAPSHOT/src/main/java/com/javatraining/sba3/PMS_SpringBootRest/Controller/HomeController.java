package com.javatraining.sba3.PMS_SpringBootRest.Controller;


import java.util.List;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.javatraining.sba3.PMS_SpringBootRest.DTO.UserInputDTO;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.UserOutputDTO;
import com.javatraining.sba3.PMS_SpringBootRest.Entity.RecentlyViewedCompanies;
import com.javatraining.sba3.PMS_SpringBootRest.Service.InvestorService;
import com.javatraining.sba3.PMS_SpringBootRest.Service.UserService;


@Controller
@RequestMapping("/home")
public class HomeController
{
	@Autowired
	private UserService userService;
	
	@Autowired 
	private InvestorService investorservice;
	
	@GetMapping("/")
	public String home(Model model)
	{
		String view="";
		UserInputDTO userInput = new UserInputDTO();
		view = "WelcomePage";
		UserOutputDTO adminDetails = this.userService.fetchBasedOnUserName("admin");
		model.addAttribute("userDetails",userInput);
		if(adminDetails==null)
		{
			UserInputDTO userInputDTO = new UserInputDTO();
			userInputDTO.setUsername("admin");
			userInputDTO.setPassword("admin");
			userInputDTO.setPan("AMLPH9140P");
			userInputDTO.setUsertype("admin");
			UserOutputDTO userAdmin = this.userService.addUser(userInputDTO);
		}
		return view;
	}
	
	@RequestMapping("/login")
	public String loginIntoPMS(@RequestParam("username") String username,@RequestParam("password") String password,Model model)
	{
		
		String view="";
		System.out.println(username+password);
		//UserOutputDTO userDetails = new UserOutputDTO();
		UserOutputDTO user = this.userService.fetchBasedOnUserNameAndPassword(username,password);
		if(user==null)
		{
			model.addAttribute("invalidCreds","invalid");
			view="WelcomePage";
		}else
		{
			String userRole = user.getUsertype(); 
			if(userRole.equalsIgnoreCase("investor"))
			{
				//List<String> portfolioValues = new ArrayList<String>();
				//********************PortfolioValues*****************
				String currentPortfolioValue = this.investorservice.getCurrentPortfolioValue().toString();
				String amountInvested = this.investorservice.getAmountInvestedTillDate().toString();
				String amountEarned = this.investorservice.getAmountEarnedTillDate().toString();
				model.addAttribute("currentPortfolioValue", currentPortfolioValue);
				model.addAttribute("amountInvested", amountInvested);
				model.addAttribute("amountEarned", amountEarned);
				//****************************************************
				List<RecentlyViewedCompanies> recentlyViewedCompanies = this.investorservice.findTopThreeRecentlyViewedCompanies();
				model.addAttribute("recentlyViewedCompanies", recentlyViewedCompanies);
				view="InvestorHome";
				
			}else if(userRole.equalsIgnoreCase("backofficer"))
			{
				view = "BackofficeUserHome";
			}else
			{
				view = "AdminHome";
			}
		}
		return view;
	}
	
	@GetMapping("/new-Investor")
	public String newInvestor(Model model)
	{
		String view="";
		UserInputDTO userInputDTO = new UserInputDTO();
		model.addAttribute("UserInputDTO",userInputDTO);
		view = "UserRegistration";
		return view;
	}
	
	
	@PostMapping("/save-Profile")
	public String saveProfile(@Valid @ModelAttribute("UserInputDTO") UserInputDTO userInputDTO,BindingResult result,Model model) 
	{
		String view="";
		if(result.hasErrors())
		{
			model.addAttribute("UserInputDTO", userInputDTO);
			view = "UserRegistration";
		}else
		{
			
			UserOutputDTO userName = this.userService.fetchBasedOnUserName(userInputDTO.getUsername());
			UserOutputDTO UserPan = this.userService.fetchBasedOnPAN(userInputDTO.getPan());
			if(userName==null && UserPan==null )
			{
				userInputDTO.setUsertype("investor");
				UserOutputDTO investorUser = this.userService.addUser(userInputDTO);
				model.addAttribute("newUserOnPMS", investorUser);
				view = "WelcomePage";
			}else
			{
				model.addAttribute("UserInputDTO", userInputDTO);
				model.addAttribute("HeaderMsg","Either Username / PAN is already registered!!");
				view = "UserRegistration";
			}
		}	
		return view;
	}
	
	
	
}