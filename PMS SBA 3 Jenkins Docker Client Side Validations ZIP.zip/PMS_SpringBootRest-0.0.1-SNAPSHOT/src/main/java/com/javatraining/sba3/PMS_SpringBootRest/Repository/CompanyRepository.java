
  package com.javatraining.sba3.PMS_SpringBootRest.Repository;
  
  import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository; 
  import org.springframework.stereotype.Component;
  import com.javatraining.sba3.PMS_SpringBootRest.Entity.CompanyProfile;
  
  @Component public interface CompanyRepository extends JpaRepository<CompanyProfile, String> 
  { 
	  List<CompanyProfile> findByCompanycodeOrCompanytitle(String companycode,String companytitle);
	  CompanyProfile findByCompanytitle(String  companytitle);
	  
	  List<CompanyProfile> findByOrderByCompanytitleAsc();
  }
 