package com.javatraining.sba3.PMS_SpringBootRest.DTO;

public class CompanyOutputDTO 
{
	 private String companycode;
	 private String companytitle;
	 private String operations; 
	 private int sharecount;
	 private double openshareprice; 	
	 private String sector;	
	 private double turnover;
	 
	public String getCompanycode() {
		return companycode;
	}
	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}
	public String getCompanytitle() {
		return companytitle;
	}
	public void setCompanytitle(String companytitle) {
		this.companytitle = companytitle;
	}
	public String getOperations() {
		return operations;
	}
	public void setOperations(String operations) {
		this.operations = operations;
	}
	public int getSharecount() {
		return sharecount;
	}
	public void setSharecount(int sharecount) {
		this.sharecount = sharecount;
	}
	public double getOpenshareprice() {
		return openshareprice;
	}
	public void setOpenshareprice(double openshareprice) {
		this.openshareprice = openshareprice;
	}
	public String getSector() {
		return sector;
	}
	public void setSector(String sector) {
		this.sector = sector;
	}
	public double getTurnover() {
		return turnover;
	}
	public void setTurnover(double turnover) {
		this.turnover = turnover;
	}
	 
	 
}
