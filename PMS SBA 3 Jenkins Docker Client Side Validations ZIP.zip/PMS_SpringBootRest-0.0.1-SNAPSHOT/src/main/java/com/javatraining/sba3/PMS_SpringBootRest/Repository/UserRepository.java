package com.javatraining.sba3.PMS_SpringBootRest.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.javatraining.sba3.PMS_SpringBootRest.Entity.User;


@Component
public interface UserRepository extends JpaRepository<User, String>

{
	User findByPan(String pan);
	User findByUsernameAndPassword(String username,String password);
}
