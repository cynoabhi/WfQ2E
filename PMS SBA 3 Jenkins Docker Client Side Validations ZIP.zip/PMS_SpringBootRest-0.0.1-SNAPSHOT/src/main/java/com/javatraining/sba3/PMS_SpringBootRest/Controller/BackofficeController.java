package com.javatraining.sba3.PMS_SpringBootRest.Controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.javatraining.sba3.PMS_SpringBootRest.DTO.CommodityDTO;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.CompanyInputDTO;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.CompanyOutputDTO;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.InvestorProfileDTO;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.StockDTO;
import com.javatraining.sba3.PMS_SpringBootRest.Entity.Commodities;
import com.javatraining.sba3.PMS_SpringBootRest.Service.BackofficerService;


@Controller
@RequestMapping("/backofficer")
public class BackofficeController 
{
	
	@Autowired 
	private BackofficerService companyService;
	 
	@GetMapping("/home-Page")
	public String backofficeUserHomePage() 
	{
		String view="";
		view = "BackofficeUserHome";
		return view;
	}
	
	//********************
	// COMPANIES
	//********************
	
	@GetMapping("/company-profile") 
	public String companyProfile(Model model) 
	{
		  String view=""; 
		  List<CompanyOutputDTO> allCompanies = companyService.fetchAllCompanies(); 
		  model.addAttribute("allCompanies",allCompanies); 
		  view = "CompanyProfile"; 
		  return view; 
	}
	
	@PostMapping("/add-company") 
	public String addCompany(Model model) 
	{ 
		String view="";
		CompanyInputDTO companyInputDTO = new CompanyInputDTO();
		model.addAttribute("CompanyInputDTO", companyInputDTO);
		view = "CreateCompanyProfile"; 
		return view; 
	}
	
	@PostMapping("/register-company-profile") 
	public String registerCompanyProfile(@Valid @ModelAttribute("CompanyInputDTO") CompanyInputDTO companyInputDTO,BindingResult result,Model model) 
	{
		String view="";
		if(result.hasErrors())
		{
			model.addAttribute("CompanyInputDTO", companyInputDTO);
			view = "CreateCompanyProfile";
		}else
		{
			CompanyOutputDTO companyOutputCompCode = this.companyService.fetchCompanyBasedOnCodeAndTitle(companyInputDTO.getCompanycode(),companyInputDTO.getCompanytitle());
			if(companyOutputCompCode==null)
			{
				CompanyOutputDTO newCompany = this.companyService.addCompany(companyInputDTO);
				List<CompanyOutputDTO> allCompanies = companyService.fetchAllCompanies(); 
				model.addAttribute("allCompanies",allCompanies); 
				model.addAttribute("HeaderMsg","Company Title: "+newCompany.getCompanytitle().toUpperCase()+" registration successful!!");
				view = "CompanyProfile";
			}else
			{
				model.addAttribute("CompanyInputDTO", companyInputDTO);
				model.addAttribute("HeaderMsg","Company Title: " +companyInputDTO.getCompanytitle()+" is already registered!!");
				view = "CreateCompanyProfile";
			}
		}	
		return view;
	}

	@GetMapping("/update-company/{companyCode}") 
	public String updateCompany(@PathVariable String companyCode,Model model) 
	{ 
		String view="";
		CompanyOutputDTO singleCompDetails = this.companyService.fetchCompanyBasedOnCode(companyCode);
		model.addAttribute("singleCompanyDetails", singleCompDetails);
		view = "ModifyCompanyProfile"; 
		return view; 
	}
	
	@PostMapping("/confirm-update-company") 
	public String confirmUpdateCompany(@Valid @ModelAttribute("singleCompanyDetails") CompanyInputDTO companyInputDTO,BindingResult result,Model model) 
	{ 
		String view="";
		if(result.hasErrors())
		{
			model.addAttribute("singleCompanyDetails", companyInputDTO);
			view = "ModifyCompanyProfile";
		}else
		{
			CompanyOutputDTO newCompany = this.companyService.fetchCompanyBasedOnTitle(companyInputDTO.getCompanytitle());
			if(newCompany==null || newCompany.getCompanycode().equalsIgnoreCase(companyInputDTO.getCompanycode()))
			{
				CompanyOutputDTO updatedCompanyDetails = this.companyService.updateCompany(companyInputDTO.getCompanycode(),companyInputDTO);
				model.addAttribute("singleCompanyDetails", updatedCompanyDetails);
				List<CompanyOutputDTO> allCompanies = companyService.fetchAllCompanies(); 
				model.addAttribute("allCompanies",allCompanies); 
				model.addAttribute("HeaderMsg","Company Title: " +updatedCompanyDetails.getCompanytitle().toUpperCase()+", changes saved successfully");
				view = "CompanyProfile";
				
			}else
			{
				model.addAttribute("singleCompanyDetails", companyInputDTO);
				model.addAttribute("HeaderMsg","Company Title: " +companyInputDTO.getCompanytitle()+" is already registered!!");
				view = "ModifyCompanyProfile";
			}
		}	
		return view;
	}
	
	
	
	//********************
	// Stocks
	//********************
	
	@GetMapping("/stocks") 
	public String stocks(Model model) 
	{
		  String view=""; 
		  // fetching companies first as stocks are added against each company
		  List<CompanyOutputDTO> allCompanies = companyService.fetchAllCompanies(); 
		  model.addAttribute("allCompanies",allCompanies); 
		  view = "Stock"; 
		  return view; 
	}
	
	@GetMapping("/company-stock-details/{companytitle}") 
	public String companyStockDetails(@PathVariable String companytitle,Model model) 
	{
		  String view=""; 
		  view = "IndividualCompanyStockDetails";
		  CompanyOutputDTO companyOutputDTO = this.companyService.fetchCompanyBasedOnTitle(companytitle);
		  List<StockDTO> singleCompanyStockDto = this.companyService.fetchStockBasedOnCompTitleInDescOrder(companytitle);
		  model.addAttribute("singleCompanyStockDto", singleCompanyStockDto);
		  model.addAttribute("companyOutputDTO", companyOutputDTO);
		  return view; 
	}
	
	@GetMapping("/add-stock-details/{companyCode}") 
	public String addStockDetails(@PathVariable String companyCode,Model model) 
	{ 
		String view="";
		StockDTO stockDto = new StockDTO();
		CompanyOutputDTO companyDetails = this.companyService.fetchCompanyBasedOnCode(companyCode);
		stockDto.setCompanycode(companyCode);
		stockDto.setCompanytitle(companyDetails.getCompanytitle());
		model.addAttribute("stockDTO", stockDto);
		view = "AddStock"; 
		return view; 
	}
	
	@PostMapping("/confirm-add-stock") 
	public String confirmAddStockDetails(@Valid @ModelAttribute("stockDTO") StockDTO stockDto,BindingResult result,Model model,RedirectAttributes redirectAtt) 
	{
		String view="";
		if(result.hasErrors())
		{
			model.addAttribute("stockDTO",stockDto);
			view = "AddStock";
		}else
		{
			StockDTO addedStockDetails = this.companyService.addStockDetails(stockDto);
			redirectAtt.addFlashAttribute("HeaderMsg","Company Title: "+addedStockDetails.getCompanytitle().toUpperCase()+", stock details added successfully!!");
			return "redirect:/backofficer/stocks";
		}	
		return view;
	}
	
	@GetMapping("/update-stock-details/{companyCode}") 
	public String updateStockDetails(@PathVariable String companyCode,Model model) 
	{ 
		String view="";
		List<StockDTO> stockDetailsOfCompany = this.companyService.fetchStockBasedOnCompCode(companyCode);
		model.addAttribute("stockDetails", stockDetailsOfCompany.get(stockDetailsOfCompany.size()-1));
		view = "UpdateStock"; 
		return view; 
	}
	
	
	
	
	@PostMapping("/confirm-update-stock") 
	public String confirmUpdateStockDetails(@Valid @ModelAttribute("stockDetails") StockDTO stockDto,BindingResult result,Model model,RedirectAttributes redirectAtt) 
	{
		String view="";
		if(result.hasErrors())
		{
			model.addAttribute("stockDTO",stockDto);
			view = "UpdateStock";
		}else
		{
			StockDTO addedStockDetails = this.companyService.addStockDetails(stockDto);
			redirectAtt.addFlashAttribute("HeaderMsg","Company Title: "+addedStockDetails.getCompanytitle().toUpperCase()+", stock details updated successfully!!");
			return "redirect:/backofficer/stocks";
		}	
		return view;
	}
	
	
	
	//********************
	// Commodities
	//********************
	
	@GetMapping("/commodities") 
	public String commodities(Model model) 
	{
		  String view=""; 
		  //List<CommodityDTO> allStocksDetails = new ArrayList<CommodityDTO>();
		  List<CommodityDTO> allCommodities = companyService.fetchAllCommodities(); 
		  model.addAttribute("allCommodities",allCommodities); 
		  view = "Commodities"; 
		  return view; 
	}
	
	@PostMapping("/add-commodity-details") 
	public String addCommodityDetails(Model model) 
	{ 
		String view="";
		CommodityDTO commodityDto = new CommodityDTO();
		model.addAttribute("commodityDTO", commodityDto);
		view = "AddCommodity"; 
		return view; 
	}
	
	@PostMapping("/confirm-add-commodity") 
	public String confirmAddCommodity(@Valid @ModelAttribute("commodityDTO") CommodityDTO commodityDto,BindingResult result,Model model,RedirectAttributes redirectAtt) 
	{ 
		String view="";
		if(result.hasErrors())
		{
			model.addAttribute("commodityDTO",commodityDto);
			view = "AddCommodity";
		}else
		{	
			List<CommodityDTO> commodity = this.companyService.fetchCommodityBasedOnCommodityName(commodityDto.getCommodityname().trim());
			if(commodity.size()<1)
			{
				CommodityDTO addedCommodityDetails = this.companyService.addCommodityDetails(commodityDto);
				redirectAtt.addFlashAttribute("HeaderMsg","Commodity: "+addedCommodityDetails.getCommodityname().toUpperCase()+", details added successfully!!");
				return "redirect:/backofficer/commodities";
				
			}else
			{
				model.addAttribute("commodityDTO", commodityDto);
				model.addAttribute("HeaderMsg","Commodity: " +commodityDto.getCommodityname().toUpperCase()+" is already added!!");
				view = "AddCommodity";
			}
		}	
		return view;
	}
	
	@GetMapping("/update-commodity-details/{commodityName}") 
	public String updateCommodityDetails(@PathVariable String commodityName,Model model) 
	{ 
		String view="";
		List<CommodityDTO> commodityDetails = this.companyService.fetchCommodityBasedOnCommodityName(commodityName);
		model.addAttribute("commodityDTO", commodityDetails.get(commodityDetails.size()-1));
		view = "UpdateCommodity"; 
		return view; 
	}
	
	@PostMapping("/confirm-update-commodity") 
	public String confirmUpdateCommodity(@Valid @ModelAttribute("commodityDTO") CommodityDTO commodityDto,BindingResult result,Model model,RedirectAttributes redirectAtt) 
	{ 
		String view="";
		if(result.hasErrors())
		{
			model.addAttribute("commodityDTO",commodityDto);
			view = "UpdateCommodity";
		}else
		{
			CommodityDTO addedCommodityDetails = this.companyService.addCommodityDetails(commodityDto);
			redirectAtt.addFlashAttribute("HeaderMsg","Commodity: "+addedCommodityDetails.getCommodityname().toUpperCase()+", details updated successfully!!");
			return "redirect:/backofficer/commodities";
		}	
		return view;
	}
	
	@GetMapping("/generate-commission-report") 
	public String generateCommissionReport(Model model) 
	{ 
		String view="";
		//List<StockDTO> stockDetailsOfCompany = this.companyService.fetchStockBasedOnCompCode(companyCode);
	//	model.addAttribute("stockDetails", stockDetailsOfCompany.get(stockDetailsOfCompany.size()-1));
		view = "GenerateCommissionReport"; 
		return view; 
	}
	
	@GetMapping("/generate-commission-report-details/{companyTitle}") 
	public String generateCommissionReportDetails(@PathVariable String companytitle, Model model) 
	{ 
		String view="";
		List<InvestorProfileDTO> investorprofiledetails = this.companyService.fetchEachCompanyTitleForSellShares();
		model.addAttribute("investorDetails", investorprofiledetails.get(investorprofiledetails.size()-1));
	//	List<InvestorProfileDTO> investorprofiledetails = this.companyService.findByCompanytitle(companytitle);
		view = "GenerateCommissionReportDetails"; 
		return view; 
	}
	
}
