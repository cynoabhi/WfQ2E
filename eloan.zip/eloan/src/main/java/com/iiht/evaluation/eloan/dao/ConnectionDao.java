package com.iiht.evaluation.eloan.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;

import com.iiht.evaluation.eloan.dto.LoanDto;
import com.iiht.evaluation.eloan.model.ApprovedLoan;
import com.iiht.evaluation.eloan.model.LoanInfo;
import com.iiht.evaluation.eloan.model.User;

public class ConnectionDao {
	private static final long serialVersionUID = 1L;
	private String jdbcURL;
	private String jdbcUsername;
	private String jdbcPassword;
	private Connection jdbcConnection;
	

	public ConnectionDao(String jdbcURL, String jdbcUsername, String jdbcPassword) {
        this.jdbcURL = jdbcURL;
        this.jdbcUsername = jdbcUsername;
        this.jdbcPassword = jdbcPassword;
    }

	public  Connection connect() throws SQLException {
		if (jdbcConnection == null || jdbcConnection.isClosed()) {
			try {
			Class.forName("com.mysql.jdbc.Driver");
				
			} catch (ClassNotFoundException e) {
				throw new SQLException(e);
			}
			jdbcConnection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
			
		}
		return jdbcConnection;
	}

	public void disconnect() throws SQLException {
		if (jdbcConnection != null && !jdbcConnection.isClosed()) {
			jdbcConnection.close();
		}
	}
	
	public  LoanInfo getLoanInfo(LoanInfo loaninfo) throws SQLException {
		
		String loannumber = loaninfo.getApplno();
		String searchQuery = "select * from loan_information where loan_app_number='"+ loannumber + "'" ;
		System.out.println("Query: "+searchQuery);
		this.connect();
		Statement stmt = this.jdbcConnection.createStatement();
		ResultSet rs =  stmt.executeQuery(searchQuery);
		while(rs.next()) {
			
			//loaninfo.setApplno(String.valueOf(rs.getInt("loan_app_number")));
			loaninfo.setApplno(rs.getString("loan_app_number"));
			loaninfo.setAmtrequest(rs.getInt("loan_amt_requested"));
			loaninfo.setDoa(rs.getString("loan_app_date"));
			loaninfo.setEmail(rs.getString("email"));
			loaninfo.setStatus(rs.getString("loan_status"));
			
		}
		this.disconnect();
		return loaninfo;
		
		
	}
	
	
	// put the relevant DAO methods here..
	public  User userLogin(User user) throws SQLException {
		String username = user.getUsername();
		String password = user.getPassword();
		
		String searchQuery = "select * from login where username='"
                + username
                + "' AND password='"
                + password
                + "'";
		// "System.out.println" prints in the console; Normally used to trace the process
	      System.out.println("Your user name is " + username);          
	      System.out.println("Your password is " + password);
	      System.out.println("Query: "+searchQuery);
	      
	      this.connect();

		Statement stmt = this.jdbcConnection.createStatement();
		ResultSet rs =  stmt.executeQuery(searchQuery);
		boolean more = rs.next();
		 if (!more) 
         {
            System.out.println("Sorry, you are not a registered user! Please sign up first");
            user.setValid(false);
         } 
		//if user exists set the isValid variable to true
         else if (more) 
         {
        	 System.out.println("Welcome to the eloan application");
             user.setValid(true);
         }
		
		 rs.close();
		stmt.close();
		this.disconnect();
		return user;
		
	}
	
	public  boolean userNewRegistration(User user) throws SQLException {
		String username = user.getUsername();
		String password = user.getPassword();
		String email = user.getEmail();
		
//String insertUserQuery = "insert into login (username, password, email) values("+""+username+","+""+password+","+email+")";
		String insertUserQuery = "insert into login (username, password, email) values(?,?,?)";
		this.connect();
		PreparedStatement pstmt = this.jdbcConnection.prepareStatement(insertUserQuery);
		
		pstmt.setString(1, username);
		pstmt.setString(2, password);
		pstmt.setString(3, email);
				
		// "System.out.println" prints in the console; Normally used to trace the process
	      System.out.println("Your user name is " + username);          
	      System.out.println("Your password is " + password);
	      System.out.println("Your email is " + email);
	      System.out.println("Query: "+insertUserQuery);		
		
	      //this.connect();

		//Statement stmt = this.jdbcConnection.createStatement();
		//int n  =  stmt.executeUpdate(insertUserQuery);
	      int n  =  pstmt.executeUpdate();
	      pstmt.close();
		
		//stmt.close();
		this.disconnect();
		
		if(n>0)
			return true;
		return false;
			
	}
	
		public  boolean saveLoanInfo(LoanInfo loaninfo) throws SQLException {
			String loanname = loaninfo.getPurpose();
			String loanapplicationnumber = loaninfo.getApplno();
			int loanamountrequested = loaninfo.getAmtrequest();
			String loandate = loaninfo.getDoa();
			String businessstructure = loaninfo.getBstructure();
			String billingindicator = loaninfo.getBindicator();
			String taxindicator = loaninfo.getTaxindicator();
			String contactaddress = loaninfo.getAddress();
			String mobile = loaninfo.getMobile();
			String email = loaninfo.getEmail();
			String status = loaninfo.getStatus();
			
			String insertUserQuery = "insert into loan_information (loan_name, loan_app_number, loan_amt_requested, loan_app_date, buisness_structure, billing_indicator, tax_indicator, contact_address, mobile, email, loan_status) values(?,?,?,?,?,?,?,?,?,?,? )";
			this.connect();
			PreparedStatement pstmt = this.jdbcConnection.prepareStatement(insertUserQuery);
			System.out.println("Query: "+insertUserQuery);
			
			pstmt.setString(1, loanname);
			pstmt.setString(2, loanapplicationnumber);
			pstmt.setInt(3, loanamountrequested);
			pstmt.setString(4, loandate);
			pstmt.setString(5, businessstructure);
			pstmt.setString(6, billingindicator);
			pstmt.setString(7, taxindicator);
			pstmt.setString(8, contactaddress);
			pstmt.setString(9, mobile);
			pstmt.setString(10, email);
			pstmt.setString(11, status);
			
			
			int n  =  pstmt.executeUpdate();
		    pstmt.close();
			this.disconnect();
						
			if(n>0)
			return true;
			return false;
		
	}

		public ArrayList<LoanInfo> listallLoanInfo(LoanInfo loaninfo) throws SQLException {
			// TODO Auto-generated method stub
			ArrayList<LoanInfo> loanlist = new ArrayList<LoanInfo>();
			String searchQuery1 = "select loan_app_number, loan_amt_requested, loan_app_date, email, loan_status from loan_information";
			this.connect();

			Statement stmt = this.jdbcConnection.createStatement();
			System.out.println(searchQuery1);
			ResultSet rs =  stmt.executeQuery(searchQuery1);
			while(rs.next()) {
				
				LoanInfo loaninfo1 = new LoanInfo();
				//loaninfo.setApplno(String.valueOf(rs.getInt("loan_app_number")));
				/*loaninfo.setApplno(rs.getString("loan_app_number"));
				System.out.println(rs.getString("loan_app_number"));
				loaninfo.setAmtrequest(rs.getInt("loan_amt_requested"));
				loaninfo.setDoa(rs.getString("loan_app_date"));
				loaninfo.setEmail(rs.getString("email"));
				loaninfo.setStatus(rs.getString("loan_status"));
				loanlist.add(loaninfo);*/
				//loanlist.add(new LoanInfo(rs.getString("loan_app_number"),rs.getInt("loan_amt_requested"), rs.getString("loan_app_date"), rs.getString("email"), rs.getString("loan_status") ));
								
				loaninfo1.setApplno(rs.getString(1));
				System.out.println(rs.getString(1));
				loaninfo1.setAmtrequest(rs.getInt(2));
				loaninfo1.setDoa(rs.getString(3));
				loaninfo1.setEmail(rs.getString(4));
				loaninfo1.setStatus(rs.getString(5));
				loanlist.add(loaninfo1);
			}

			this.disconnect();
			System.out.println(loanlist);
			return loanlist;
					
		}

		public LoanInfo geteditLoanInfo(LoanInfo loaninfo) throws SQLException {
			// TODO Auto-generated method stub
			String loannumber = loaninfo.getApplno();
			String searchQuery2 = 
					"select loan_app_number, loan_amt_requested, loan_app_date, email,loan_status, contact_address, mobile, buisness_structure, billing_indicator, tax_indicator from loan_information where loan_app_number='"+ loannumber + "'" ;
			this.connect();
			Statement stmt = this.jdbcConnection.createStatement();
			System.out.println(searchQuery2);
			ResultSet rs =  stmt.executeQuery(searchQuery2);
			while(rs.next()) {
				loaninfo.setApplno(rs.getString("loan_app_number"));
				loaninfo.setAmtrequest(rs.getInt("loan_amt_requested"));
				loaninfo.setDoa(rs.getString("loan_app_date"));
				loaninfo.setEmail(rs.getString("email"));
				loaninfo.setStatus(rs.getString("loan_status"));
				loaninfo.setAddress(rs.getString("contact_address"));
				loaninfo.setMobile(rs.getString("mobile"));
				loaninfo.setTaxindicator(rs.getString("tax_indicator"));
				loaninfo.setBindicator(rs.getString("billing_indicator"));
				loaninfo.setBstructure(rs.getString("buisness_structure"));
				
			}
			
			return loaninfo;
		}

		public boolean updateLoanInfo(LoanInfo loaninfo) throws SQLException {
			
			String loannumber = loaninfo.getApplno();
			System.out.println("The value in Dao for loanappnumber is "+loannumber);
			int loanamountrequested = loaninfo.getAmtrequest();
			String loandate = loaninfo.getDoa();
			String businessstructure = loaninfo.getBstructure();
			String billingindicator = loaninfo.getBindicator();
			String taxindicator = loaninfo.getTaxindicator();
			String contactaddress = loaninfo.getAddress();
			String mobile = loaninfo.getMobile();
			String email = loaninfo.getEmail();
			String status = loaninfo.getStatus();
			this.connect();
			//String updatesql = "UPDATE loan_information SET loan_amt_requested= '444' WHERE loan_app_number='12777'";
			String updatesql = "UPDATE loan_information SET loan_amt_requested= '"+loanamountrequested+"',"
					+"loan_app_date= '"+loandate+"', "
					+"email  = '"+email+"', "
					//+"loan_status = '"+status+"', "
					+"contact_address = '"+contactaddress+"', "
					+"mobile = '"+mobile+"', "
					+"buisness_structure = '"+businessstructure+"', "
					+"billing_indicator = '"+billingindicator+"', "
					+"tax_indicator = '"+taxindicator+"' "
					+"WHERE loan_app_number = '"+loannumber+"';";
					
					
					//WHERE loan_app_number='"+loannumber+"'";
			/*String updatesql = "UPDATE loan_information "
			+"SET loan_amt_requested = ? "
			+"WHERE loan_app_number ="+loannumber;*/
			//System.out.println("Query: "+updatesql);
			
		//	PreparedStatement pstmt = this.jdbcConnection.prepareStatement(updatesql);
		//	pstmt.setString(1, Integer.toString(loanamountrequested1));
		//	pstmt.setString(2, loannumber);

			/*pstmt.setString(1, Integer.toString(loanamountrequested));
			pstmt.setString(2, loandate);
			pstmt.setString(3, email);
			pstmt.setString(4, status);
			pstmt.setString(5, contactaddress);
			pstmt.setString(6, mobile);
			pstmt.setString(7, businessstructure);
			pstmt.setString(8, billingindicator);
			pstmt.setString(9, taxindicator);			
			pstmt.setString(10, loannumber);*/
			
					
		//	int n =  pstmt.executeUpdate(updatesql);
		//	pstmt.close();
			Statement stmt = this.jdbcConnection.createStatement();
			System.out.println(updatesql);
			int n  =  stmt.executeUpdate(updatesql);
			
			this.disconnect();
						
			if(n>0)
			return true;
			return false;
			
		}

		public boolean processLoanInfo(ApprovedLoan approvedloan) throws SQLException {
			// TODO Auto-generated method stub
			
			String loannumber = approvedloan.getApplno();
			System.out.println("The value in Dao for loanappnumber is "+loannumber);
			int loanamtsanctioned = approvedloan.getAmotsanctioned();
			System.out.println("The value of loanamtsanctioned is "+loanamtsanctioned);
			String paystartdate = approvedloan.getPsd();
			System.out.println("The value of paystartdate is "+paystartdate);
			String loanclosuredate = approvedloan.getLcd();
			System.out.println("The value of loanclosuredate is "+loanclosuredate);
			int termofloan = approvedloan.getLoanterm();
			//int monthlypayment = approvedloan.getEmi();
			int rateofloan = 8;	
		//	int termofloan = 12;
					
		//	int termpayamount = 	(loanamtsanctioned)*(1+rateofloan/100)^termofloan;	
			int termpayamount = 	(int) ((loanamtsanctioned)* Math.pow(1+(rateofloan/100), termofloan));
			int monthlypayment = (termpayamount )/(termofloan);
			
			System.out.println("the value for termofloan "+termofloan);
			System.out.println("the value for termpayamount "+termpayamount);
			System.out.println("the value for monthlypayment "+monthlypayment);
			
			
			this.connect();
			
			String processsql = "UPDATE loan_information SET loan_amt_sanctioned= '"+loanamtsanctioned+"',"
					+"pay_start_date= '"+paystartdate+"', "
					+"loan_closure_date  = '"+loanclosuredate+"', "
					+"loan_status = 'sanctioned' "					
					+"WHERE loan_app_number = '"+loannumber+"';";
					
			Statement stmt = this.jdbcConnection.createStatement();
			System.out.println(processsql);
			int n  =  stmt.executeUpdate(processsql);
			
			this.disconnect();
						
			if(n>0)
			return true;
			return false;
						
		}
	
}
