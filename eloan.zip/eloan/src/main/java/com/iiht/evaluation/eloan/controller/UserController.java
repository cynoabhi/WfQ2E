package com.iiht.evaluation.eloan.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iiht.evaluation.eloan.dao.ConnectionDao;
import com.iiht.evaluation.eloan.model.ApprovedLoan;
import com.iiht.evaluation.eloan.model.LoanInfo;
import com.iiht.evaluation.eloan.model.User;
import com.mysql.cj.xdevapi.Statement;


@WebServlet("/user")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
private ConnectionDao connDao;
	
	public void setConnDao(ConnectionDao connDao) {
		this.connDao = connDao;
	}
	public void init(ServletConfig config) {
		String jdbcURL = config.getServletContext().getInitParameter("jdbcUrl");
		String jdbcUsername = config.getServletContext().getInitParameter("jdbcUsername");
		String jdbcPassword = config.getServletContext().getInitParameter("jdbcPassword");
		System.out.println(jdbcURL +" " + jdbcUsername + " " + jdbcPassword);
		this.connDao = new ConnectionDao(jdbcURL, jdbcUsername, jdbcPassword);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		System.out.println("The value of action is "+action);
		//String action = "validate";
		
		String viewName = "";
		try {
			switch (action) {
			case "registernewuser":
				viewName=registernewuser(request,response);
				break;
			case "validate":
				viewName=validate(request,response);
				//viewName = "adminhome1.jsp";
				break;
			case "placeloan":
				viewName=placeloan(request,response);
				break;
			case "application1":
				viewName=application1(request,response);
				break;
			case "editLoanProcess"  :
				viewName=editLoanProcess(request,response);
				break;
			case "registeruser":
				viewName=registerUser(request,response);
				break;
			case "register":
				viewName = register(request, response);
				break;
			case "application":
				viewName = application(request, response);
				break;
			case "trackloan":
				viewName = trackloan(request, response);
				break;
			case "editloan":
				viewName = editloan(request, response);
				break;	
			case  "displaystatus" :
				viewName=displaystatus(request,response);
				break;
			default : viewName = "notfound.jsp"; break;	
			}
		} catch (Exception ex) {
			
			throw new ServletException(ex.getMessage());
		}
			RequestDispatcher dispatch = 
					request.getRequestDispatcher(viewName);
			System.out.println("The value of viewname is "+viewName);
			dispatch.forward(request, response);
	}
	private String validate(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		/* write the code to validate the user */
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String viewadmin = "adminhome1.jsp";
		String viewuser = "userhome1.jsp";
		System.out.println("userame is "+username+" password is "+password);
		Boolean adminuser = (username.equals("admin") && password.equals("admin")) ;
		/*{
			//response.sendRedirect("adminhome1.jsp");
			String viewadmin = "adminhome1.jsp";
		//return viewadmin;
		return viewadmin;
		}
		return password;
		*/
		if(adminuser == true) 
			return viewadmin;
	//	else 
		//	return viewuser;*/
			
			User user = new User();
			user.setUsername(username);
			user.setPassword(password);
			user = connDao.userLogin(user);
			if(user.isValid())
				return viewuser;
			
			
			return "index.jsp" + "";
			
		
		
	}
	private String placeloan(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
	/* write the code to place the loan information */
		
		return null;
	}
	private String application1(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
	/* write the code to display the loan application page */
		return "application.jsp";
	}
	private String editLoanProcess(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		// TODO Auto-generated method stub
		/* write the code to edit the loan info */
		String loannumber = request.getParameter("loannumber");
		System.out.println("loannumber::" +loannumber);
		LoanInfo loaninfo = new LoanInfo();
		loaninfo.setApplno(loannumber);
		LoanInfo loaninforeturned = connDao.geteditLoanInfo(loaninfo);
		request.setAttribute("loanamtrequested", loaninforeturned.getAmtrequest());
		request.setAttribute("loanemail", loaninforeturned.getEmail());
		request.setAttribute("loanmobile", loaninforeturned.getMobile());
		request.setAttribute("loancontactaddress", loaninforeturned.getAddress());
		request.setAttribute("loanappdate", loaninforeturned.getDoa());
		request.setAttribute("loanappnumber", loaninforeturned.getApplno());
		System.out.println("loanappnumber::"+loaninforeturned.getApplno());
		request.setAttribute("loantaxindicator", loaninforeturned.getTaxindicator());
		request.setAttribute("loanbindicator", loaninforeturned.getBindicator());
		request.setAttribute("loanbstructure", loaninforeturned.getBstructure());
		
		
		return "editloanui.jsp";
	}
	private String registerUser(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		// TODO Auto-generated method stub
		/* write the code to redirect page to read the user details */
		//return "newuserui.jsp";
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String email = request.getParameter("email");
		User user = new User();
		user.setUsername(username);
		user.setPassword(password);
		user.setEmail(email);
		
		boolean insertStatus = connDao.userNewRegistration(user);
		if(insertStatus)
		return "index.jsp";
		else
		return "newuserui.jsp";
	}
	private String registernewuser(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		// TODO Auto-generated method stub
		/* write the code to create the new user account read from user 
		   and return to index page */
		
		//return null;
		return "newuserui.jsp";
	}
	
	private String register(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		// TODO Auto-generated method stub
		/* write the code to redirect to register page */
		
		String loanappnumber = request.getParameter("loanapplicationnumber");
		String loanamtrequested = request.getParameter("loanamountrequested");
		String loandate = request.getParameter("loandate");
		String loanbstructure = request.getParameter("businessstructure");
		String loanbindicator = request.getParameter("billingindicator");
		String loantaxindicator = request.getParameter("taxindicator");
		String loanaddress = request.getParameter("contactaddress");
		String mobile = request.getParameter("mobile");
		String email = request.getParameter("email");
				
		LoanInfo loaninfo = new LoanInfo();
		loaninfo.setApplno(loanappnumber);
		loaninfo.setAmtrequest(Integer.parseInt(loanamtrequested));
		loaninfo.setDoa(loandate);
		loaninfo.setBstructure(loanbstructure);
		loaninfo.setBindicator(loanbindicator);
		loaninfo.setTaxindicator(loantaxindicator);
		loaninfo.setAddress(loanaddress);
		loaninfo.setMobile(mobile);
		loaninfo.setEmail(email);
		System.out.println("Now entering the updateloaninfo");
		boolean loaninforeturned = connDao.updateLoanInfo(loaninfo);	
		if(loaninforeturned)
			return "userhome1.jsp";
			else
			return "editloanui.jsp";
		
		
	}
	private String displaystatus(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		// TODO Auto-generated method stub
		/* write the code the display the loan status based on the given application
		   number 
		*/
		String loannumber = request.getParameter("loannumber");
		LoanInfo loaninfo = new LoanInfo();
		loaninfo.setApplno(loannumber);
		LoanInfo loaninforeturned = connDao.getLoanInfo(loaninfo);
		System.out.println(loaninforeturned.getAmtrequest());
		request.setAttribute("loanamtrequested", loaninforeturned.getAmtrequest());
		request.setAttribute("loanstatus", loaninforeturned.getStatus());
		request.setAttribute("email", loaninforeturned.getEmail());
		request.setAttribute("loanappdate", loaninforeturned.getDoa());
		request.setAttribute("loannumber", loaninforeturned.getApplno());
		
		
		
		return "loanDetails.jsp";
	}

	private String editloan(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		// TODO Auto-generated method stub
	/* write a code to return to editloan page */
		/*String loannumber = request.getParameter("loannumber");
		System.out.println("loannumber::" +loannumber);
		LoanInfo loaninfo = new LoanInfo();
		loaninfo.setApplno(loannumber);
		LoanInfo loaninforeturned = connDao.geteditLoanInfo(loaninfo);
		request.setAttribute("loanamtrequested", loaninforeturned.getAmtrequest());
		request.setAttribute("loanemail", loaninforeturned.getEmail());
		request.setAttribute("loanmobile", loaninforeturned.getMobile());
		request.setAttribute("loancontactaddress", loaninforeturned.getAddress());
		request.setAttribute("loanappdate", loaninforeturned.getDoa());
		request.setAttribute("loanappnumber", loaninforeturned.getApplno());
		System.out.println("loanappnumber::"+loaninforeturned.getApplno());
		request.setAttribute("loantaxindicator", loaninforeturned.getTaxindicator());
		request.setAttribute("loanbindicator", loaninforeturned.getBindicator());
		request.setAttribute("loanbstructure", loaninforeturned.getBstructure());*/
		
		
		
		
		
		return "editloan.jsp";
	}

	private String trackloan(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
	/* write a code to return to trackloan page */
		
		return "trackloan.jsp";
	}

	private String application(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		// TODO Auto-generated method stub
	/* write a code to return to trackloan page */
		String loanname = request.getParameter("loanname");
		String loanapplicationnumber = request.getParameter("loanapplicationnumber");
		int loanamountrequested = Integer.parseInt((request.getParameter("loanamountrequested")));
		String loandate = request.getParameter("loandate");
		String businessstructure = request.getParameter("businessstructure");
		String billingindicator = request.getParameter("billingindicator");
		String taxindicator = request.getParameter("taxindicator");
		String contactaddress = request.getParameter("contactaddress");
		String mobile = request.getParameter("mobile");
		String email = request.getParameter("email");
		String status = "not sanctioned";
		
		LoanInfo loaninfo = new LoanInfo();
		loaninfo.setApplno(loanapplicationnumber);
		loaninfo.setPurpose(loanname);
		loaninfo.setAmtrequest(loanamountrequested);
		loaninfo.setDoa(loandate);
		loaninfo.setBstructure(businessstructure);
		loaninfo.setBindicator(billingindicator);
		loaninfo.setTaxindicator(taxindicator);
		loaninfo.setAddress(contactaddress);
		loaninfo.setMobile(mobile);
		loaninfo.setEmail(email);
		loaninfo.setStatus(status);
		boolean insertStatus =  connDao.saveLoanInfo(loaninfo);
		if(insertStatus)
			return "trackloan.jsp";
			else
			return "application.jsp";
		
		
		
		
	}
}